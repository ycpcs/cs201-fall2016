package edu.ycp.cs201.lists;

public class LinkedListNode<E> {
	E payload;
	LinkedListNode<E> next;
}
