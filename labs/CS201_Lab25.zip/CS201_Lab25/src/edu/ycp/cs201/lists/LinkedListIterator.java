package edu.ycp.cs201.lists;

import java.util.Iterator;

public class LinkedListIterator<E> implements Iterator<E> {
	private LinkedListNode<E> cur;

	public LinkedListIterator(LinkedListNode<E> head) {
		cur= head;
	}
	
	@Override
	public boolean hasNext() {
		return cur != null;
	}

	@Override
	public E next() {
		E val = cur.payload;
		
		cur = cur.next;
		
		return val;
	}

	@Override
	public void remove() {
		// NOTE: implementing this method is challenging.
		throw new UnsupportedOperationException();
	}

}
