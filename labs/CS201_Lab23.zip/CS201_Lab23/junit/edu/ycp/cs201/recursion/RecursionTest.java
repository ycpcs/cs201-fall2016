package edu.ycp.cs201.recursion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class RecursionTest {
	private List<Integer> aList;

	@Before
	public void setUp() {
		aList = new ArrayList<Integer>();
		aList.add(42);
		aList.add(8);
		aList.add(414);
		aList.add(122);
	}

	@Test
	public void testMergeSort() throws Exception {
		Recursion.mergeSort(aList);
		
		System.out.println("aList: " + aList);
		
		assertEquals((Integer) 8, aList.get(0));
		assertEquals((Integer) 42, aList.get(1));
		assertEquals((Integer) 122, aList.get(2));
		assertEquals((Integer) 414, aList.get(3));
	}

	@Test
	public void testMergeSortLarge() throws Exception {
		// make a list containing a large number of random integers
		Random rand = new Random(123L);
		ArrayList<Integer> bigList = new ArrayList<Integer>();
		for (int i = 0; i < 1000000; i++) {
			bigList.add(rand.nextInt(10000000));
		}

		// sort
		Recursion.mergeSort(bigList);

		// verify that the list is sorted
		for (int i = 1; i < bigList.size(); i++) {
			assertTrue(bigList.get(i-1).compareTo(bigList.get(i)) <= 0);
		}
	}

	@Test
	public void testPermute() throws Exception {
		Set<List<Integer>> permutations = Recursion.permute(aList);

		// make a copy of the set where all elements belong to whatever class
		// is returned by Arrays.asList
		Set<List<Integer>> permutationsCopy = new HashSet<List<Integer>>();
		for (List<Integer> permutation : permutations) {
			Integer[] a = permutation.toArray(new Integer[permutation.size()]);
			permutationsCopy.add(Arrays.asList(a));
		}

		// verify that all permutations were generated - there should be 4 * 3 * 2 * 1 = 24
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{8,42,122,414})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{8,42,414,122})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{8,122,42,414})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{8,122,414,42})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{8,414,42,122})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{8,414,122,42})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{42,8,122,414})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{42,8,414,122})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{42,122,8,414})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{42,122,414,8})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{42,414,8,122})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{42,414,122,8})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{122,8,42,414}))); 
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{122,8,414,42})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{122,42,8,414})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{122,42,414,8})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{122,414,8,42})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{122,414,42,8})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{414,8,42,122})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{414,8,122,42})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{414,42,8,122})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{414,42,122,8})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{414,122,8,42})));
		assertTrue(permutationsCopy.contains(Arrays.asList(new Integer[]{414,122,42,8})));
	}
}
