package edu.ycp.cs201.sort;

public class Sort {
	
	/**
	 * Sort an array using insertion sort.
	 * 
	 * @param <E> element type
	 * @param arr an array
	 */
	public static<E extends Comparable<E>> void insertionSort(E[] arr) {
		insertionSortWork(arr, 0, 1);
	}

	/**
	 * Sort an array using shell sort.
	 * 
	 * @param <E> element type
	 * @param arr an array
	 */
	public static<E extends Comparable<E>> void shellSort(E[] arr) {
		// TODO: implement
	}

	/**
	 * Worker method for implementing insertion sort and shell sort.
	 * Performs an insertion sort starting at given index,
	 * and skipping every gap number of elements.
	 * 
	 * @param <E> type of element being sorted
	 * @param arr         the array being sorted
	 * @param startIndex  start index
	 * @param gap         gap distance: how many elements are skipped
	 */
	public static<E extends Comparable<E>> void insertionSortWork(E[] arr, int startIndex, int gap) {
		for (int j = startIndex + gap; j < arr.length; j += gap) {
			for (int i = j; i > startIndex; i -= gap) {
				if (arr[i - gap].compareTo(arr[i]) <= 0) {
					break;
				}
				swap(arr, i - gap, i);
			}
		}
	}

	public static<E> void swap(E[] arr, int i, int j) {
		E tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}

}
