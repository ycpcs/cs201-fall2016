package edu.ycp.cs201.sort;

import java.util.Random;

public class Benchmark {
	
	private static final int CHUNK = 10000;
	
	public static void main(String[] args) {
		for (int size = CHUNK; size <= 10*CHUNK; size += CHUNK) {
			// TODO:
			//    1. create an unsorted array of given size,
			//       time how long to sort it using Sort.insertionSort
			//
			//    2. create an unsorted array of given size,
			//       time how long to sort it using Sort.shellSort
			//
			// Output a data point in the format
			//
			//     size,insSortTime,shellSortTime
			
		}
	}

	private static Integer[] createUnsortedArray(int size) {
		Random r = new Random((long) 0xDEADBEEF);
		Integer[] a = new Integer[size];
		for (int i = 0; i < size; i++) {
			a[i] = Integer.valueOf(r.nextInt(10000000));
		}
		return a;
	}
}
