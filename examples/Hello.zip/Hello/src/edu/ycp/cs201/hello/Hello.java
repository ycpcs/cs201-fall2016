package edu.ycp.cs201.hello;

import java.util.Scanner;

public class Hello {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter two integers: ");
		int a=  keyboard.nextInt();
		int b = keyboard.nextInt();
		
		int sum = a + b;
		
		System.out.printf("Sum is %d\n", sum);
	}
}
