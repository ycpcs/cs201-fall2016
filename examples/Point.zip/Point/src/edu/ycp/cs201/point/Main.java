package edu.ycp.cs201.point;

public class Main {
	public static void main(String[] args) {
		Point p = new Point(3.0, 4.0);
		System.out.printf("%f,%f\n", p.getX(), p.getY());
		
		Point origin = new Point(0.0, 0.0);
		
		System.out.printf("dist=%f\n", p.distance(origin));
	}
}
