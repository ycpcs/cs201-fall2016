package edu.ycp.cs201.point;

public class Point {
	private double x;
	private double y;
	
	public Point(double xinit, double yinit) {
		this.x = xinit;
		this.y = yinit;
	}
	
	public double getX() {
		return this.x;
	}
	
	public double getY() {
		return this.y;
	}
	
	public double distance(Point other) {
		double xdiff = this.x - other.x;
		double ydiff = this.y - other.y;
		return Math.sqrt(xdiff*xdiff + ydiff*ydiff);
	}
}
