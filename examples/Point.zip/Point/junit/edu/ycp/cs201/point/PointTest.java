package edu.ycp.cs201.point;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.000001;
	
	// test fixture
	private Point p;
	private Point origin;
	
	// setup method
	@Before
	public void setup() {
		p = new Point(3.0, 4.0);
		origin = new Point(0.0, 0.0);
	}
	
	// test methods
	@Test
	public void testGetX() throws Exception {
		assertEquals(3.0, p.getX(), DELTA);
		assertEquals(0.0, origin.getX(), DELTA);
	}
	
	@Test
	public void testGetY() throws Exception {
		assertEquals(4.0, p.getY(), DELTA);
		assertEquals(0.0, origin.getY(), DELTA);
	}
	
	@Test
	public void testDistance() throws Exception {
		assertEquals(5.0, p.distance(origin), DELTA);
		assertEquals(5.0, origin.distance(p), DELTA);
	}
}
