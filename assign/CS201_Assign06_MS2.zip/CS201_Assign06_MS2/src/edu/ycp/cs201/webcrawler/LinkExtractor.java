package edu.ycp.cs201.webcrawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashSet;
import java.util.Set;

/**
 * Extract links from a web page.
 */
public class LinkExtractor {
	// TODO: add field(s)
	
	/**
	 * Constructor.
	 */
	public LinkExtractor() {
		// TODO: initialize field(s)
	}
	
	/**
	 * Process one line of a web page to check whether there is
	 * a link on it.  If so, the link should be extracted and added
	 * to the set of links.
	 * 
	 * @param line one line of a web page
	 */
	public void processLine(String line) {
		// TODO: implement
	}

	/**
	 * @return the set of extracted links
	 */
	public Set<String> getExtractedLinks() {
		throw new UnsupportedOperationException("TODO - implement");
	}

	/**
	 * Helper method to use a {@link LinkExtractor} to extract all links
	 * from a web page.  Returns <code>null</code> if the specified
	 * {@link URL} names a nonexistent web page (i.e., is a broken link).
	 * 
	 * @param url      the {@link URL} of a web page whose links should be extracted
	 * @param fetcher  the {@link Fetcher} which should be used to
	 *                 fetch the document named by the {@link URL}
	 * @return set of extracted links, or null if the {@link URL}
	 *         names a nonexistent resource (i.e., is a broken link)
	 */
	public static Set<String> extractLinks(URL url, Fetcher fetcher) {
		try {
			Reader r = fetcher.open(url);
			if (r == null) {
				// Resource does not exist!
				return null;
			}
			BufferedReader br = new BufferedReader(r);
			LinkExtractor lx = new LinkExtractor();
			try {
				while (true) {
					String line = br.readLine();
					if (line == null) {
						break;
					}
					lx.processLine(line);
				}
			} finally {
				br.close();
			}
			
			Set<String> links = lx.getExtractedLinks();
//			System.out.println("Extracted " + links.size() + " links");
			return links;
		} catch (IOException e) {
			throw new IllegalStateException("Could not extract links from " + url.toString(), e);
		}
	}
	
	/*
	public static void main(String[] args) throws IOException {
		Fetcher f = new Fetcher(new URL("https://ycpcs.github.io/cs201-fall2016/assign/exampleSite/"));
		URL u = new URL("https://ycpcs.github.io/cs201-fall2016/assign/exampleSite/index.html");
		BufferedReader r = new BufferedReader(f.open(u));
		LinkExtractor lx = new LinkExtractor();
		try {
			while (true) {
				String line = r.readLine();
				if (line == null) {
					break;
				}
//				System.out.println(line);
				lx.processLine(line);
			}
		} finally {
			r.close();
		}
		
		Set<String> links = lx.getExtractedLinks();
		System.out.println("Extracted " + links.size() + " links");
	}
	*/
}
