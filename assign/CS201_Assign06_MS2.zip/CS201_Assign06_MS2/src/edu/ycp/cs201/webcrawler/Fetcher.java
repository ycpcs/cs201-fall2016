package edu.ycp.cs201.webcrawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class for fetching resources named by {@link URL}s.
 */
public class Fetcher {
	private URL startURL;
	
	/**
	 * Constructor.
	 * 
	 * @param startURL the URL of the "start" resource:
	 *                 all resources fetched (using the {@link #open(URL)}
	 *                 method) must have a directory that is a subdirectory
	 *                 of this URL's directory
	 */
	public Fetcher(URL startURL) {
		this.startURL = startURL;
	}
	
	/**
	 * Check whether this object is allowed to fetch the specified
	 * {@link URL}.  Only URLs naming text resources in a subdirectory of the
	 * start URL (i.e., the one passed to the constructor)
	 * are allowed to be fetched.
	 * 
	 * <p>Note that this method returning true does <em>not</em> guarantee that
	 * this object will be able to fetch the resource named by the URL.
	 * (For example, the URL might name a nonexistent resource.)
	 * 
	 * @param url a {@link URL}
	 * @return true if the resource named by the URL is allowed to be fetched,
	 *         false otherwise
	 */
	public boolean allowFetch(URL url) {
		String path = url.getPath();
		int lastDot = path.lastIndexOf('.');
		if (lastDot < 0) {
			return false;
		}
		String fileExt = path.substring(lastDot);
		if (!fileExt.equals(".html") && !fileExt.equals(".htm") && !fileExt.equals(".txt")) {
			return false;
		}
		return url.getDirectoryPart().startsWith(this.startURL.getDirectoryPart());
	}
	
	private static final Pattern CHARSET_PAT = Pattern.compile(";\\s*charset=(\\S+)\\s*$");
	
	/**
	 * Open a Reader reading from the resource named by the
	 * specified {@link URL}.  <em>Only text resources such as
	 * HTML documents can be opened by this method.</em>
	 * 
	 * @param url the {@link URL} naming the resource to read from
	 * @return a {@link Reader}, or null if the resource does not exist
	 * 
	 * @throws IllegalArgumentException if {@link #allowFetch(URL)}
	 *    returns false for the specified {@link URL}, or if the
	 *    requested resource is not a text resource
	 */
	public Reader open(URL url) {
		if (!allowFetch(url)) {
			throw new IllegalArgumentException("Resource " + url.toString() + " is not allowed");
		}
		
		String s = url.toString();
		if (!s.endsWith(".html") && !s.endsWith(".htm") && !s.endsWith(".txt")) {
			throw new IllegalArgumentException(url + " is not a text resource");
		}
		
		try {
			java.net.URL jnu = new java.net.URL(url.toString());
			
			URLConnection c;
			try {
				c = jnu.openConnection();
			} catch (IOException e) {
				// We assume that the connection couldn't be opened because
				// the resource does not exist.
				return null;
			}
			
			String contentType = c.getContentType();
			
			String charset = "utf-8";
			if (contentType != null) {
//				System.out.println("Content type is " + contentType);
				if (!contentType.startsWith("text/")) {
					throw new IllegalArgumentException("Not a text resource");
				}
				Matcher m = CHARSET_PAT.matcher(contentType);
				if (m.matches()) {
					charset = m.group(1);
//					System.out.println("#### charset=" + charset + " ####");
				}
			}
			
			try {
				return new InputStreamReader(c.getInputStream(), charset);
			} catch (IOException e) {
				// As above, assume that we can't open the stream because
				// the resource doesn't exist.
				return null;
			}
		} catch (Exception e) {
			throw new RuntimeException("Failed to read from " + url.toString(), e);
		}
	}

	/**
	 * Check whether or not the resource named by the
	 * given {@link URL} exists.
	 * 
	 * @param url a {@link URL}
	 * @return true if the resource named by the URL exists, false otherwise
	 */
	public boolean exists(URL url) {
		Reader r = null;
		try {
			r = open(url);
			return r != null;
		} finally {
			if (r != null) {
				try {
					r.close();
				} catch (IOException e) {
					// ignore exception
				}
			}
		}
	}

	/*
	public static void main(String[] args) throws IOException {
		Fetcher f = new Fetcher(new URL("http://faculty.ycp.edu/~dhovemey/"));
		URL u = new URL("http://faculty.ycp.edu/~dhovemey/index.html");
		Reader r = f.open(u);
		if (r == null) {
			System.out.println("Resource doesn't exist");
			return;
		}
		BufferedReader br = new BufferedReader(r);
		try {
			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
		} finally {
			br.close();
		}
	}
	*/
}
