package edu.ycp.cs201.webcrawler;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class LinkExtractorTest {
	private File baseDir;
	
	@Before
	public void setUp() throws Exception {
		baseDir = new File(".").getCanonicalFile();
	}

	private Set<String> extractLinks(String doc) throws FileNotFoundException, IOException {
		LinkExtractor lx = new LinkExtractor();
		BufferedReader br = new BufferedReader(new FileReader(new File(baseDir, doc)));
		while (true) {
			String line = br.readLine();
			if (line == null) {
				break;
			}
			lx.processLine(line);
		}
		br.close();
		
		Set<String> links = lx.getExtractedLinks();
		return links;
	}
	
	@Test
	public void testExtractLinks1() throws Exception {
		Set<String> links = extractLinks("exampleSite/index.html");
		assertEquals(2, links.size());
		assertTrue(links.contains("coolStuff.html"));
		assertTrue(links.contains("info/resources.html"));
	}
	
	@Test
	public void testExtractLinks2() throws Exception {
		Set<String> links = extractLinks("exampleSite/coolStuff.html");
		assertEquals(2, links.size());
		assertTrue(links.contains("./index.html"));
		assertTrue(links.contains("./news/notThere.html"));
	}
	
	@Test
	public void testExtractLinks3() throws Exception {
		Set<String> links = extractLinks("exampleSite/info/resources.html");
		assertEquals(5, links.size());
		assertTrue(links.contains("moreResources.html"));
		assertTrue(links.contains("../lizards.html"));
		assertTrue(links.contains("books.html"));
		assertTrue(links.contains("music.html"));
		assertTrue(links.contains("pictures/gallery.html"));
	}
	
	@Test
	public void testExtractLinks4() throws Exception {
		Set<String> links = extractLinks("exampleSite/lizards.html");
		assertEquals(2, links.size());
		assertTrue(links.contains("monitorLizards.html"));
		assertTrue(links.contains("komodoDragons.html"));
	}
	
	@Test
	public void testExtractLinks5() throws Exception {
		Set<String> links = extractLinks("exampleSite/info/books.html");
		assertEquals(1, links.size());
		assertTrue(links.contains("./music.html"));
	}
	
	@Test
	public void testExtractLinks6() throws Exception {
		Set<String> links = extractLinks("exampleSite/info/music.html");
		assertEquals(1, links.size());
		assertTrue(links.contains("../info/./books.html"));
	}
	
	@Test
	public void testExtractLinks7() throws Exception {
		Set<String> links = extractLinks("exampleSite/info/pictures/gallery.html");
		assertEquals(1, links.size());
		assertTrue(links.contains("../../secret.html"));
	}
	
	@Test
	public void testExtractLinks8() throws Exception {
		Set<String> links = extractLinks("exampleSite/monitorLizards.html");
		assertEquals(0, links.size());
	}
	
	@Test
	public void testExtractLinks9() throws Exception {
		Set<String> links = extractLinks("exampleSite/secret.html");
		assertEquals(0, links.size());
	}
}
