package edu.ycp.cs201.webcrawler;

public class HttpCrawlerTest extends CrawlerTest {
	@Override
	public URL getStartURL() throws Exception {
		return new URL("https://ycpcs.github.io/cs201-fall2016/assign/exampleSite/index.html");
	}
}
