package edu.ycp.cs201.webcrawler;

import java.io.File;

public class FileCrawlerTest extends CrawlerTest {
	@Override
	public URL getStartURL() throws Exception {
		File baseDir = new File(".").getCanonicalFile();
		return new URL("file:" + baseDir.toString() + "/exampleSite/index.html");
	}
}
