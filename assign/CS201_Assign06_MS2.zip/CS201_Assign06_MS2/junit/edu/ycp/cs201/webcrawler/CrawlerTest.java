package edu.ycp.cs201.webcrawler;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.Test;

public abstract class CrawlerTest {
	public abstract URL getStartURL() throws Exception;
	
	@Test
	public void testCrawlExampleSite() throws Exception {
		URL startURL = getStartURL();
		
		String s = startURL.toString();
		int lastSlash = s.lastIndexOf('/');
		String dirPart = s.substring(0, lastSlash + 1);
		System.out.println("dirPart="+dirPart);
		
		Crawler crawler = new Crawler(startURL);
		crawler.crawl();
		
		Set<URL> visited = crawler.getVisited();
		assertEquals(9, visited.size());
		
		assertTrue(visited.contains(new URL(dirPart + "index.html")));
		assertTrue(visited.contains(new URL(dirPart + "monitorLizards.html")));
		assertTrue(visited.contains(new URL(dirPart + "info/pictures/gallery.html")));
		assertTrue(visited.contains(new URL(dirPart + "secret.html")));
		assertTrue(visited.contains(new URL(dirPart + "lizards.html")));
		assertTrue(visited.contains(new URL(dirPart + "info/books.html")));
		assertTrue(visited.contains(new URL(dirPart + "info/music.html")));
		assertTrue(visited.contains(new URL(dirPart + "info/resources.html")));
		assertTrue(visited.contains(new URL(dirPart + "coolStuff.html")));
	}
}
