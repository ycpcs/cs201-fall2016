package edu.ycp.cs201.guicompthread;

import java.util.Random;

// Compute takes a Region and produces a Model.
public class Compute {
	private Region region;
	private Model model;
	
	private Random rand;
	
	public Compute(Region region) {
		this.region = region;
		this.model = new Model();
		this.rand = new Random();
	}
	
	public Model getModel() {
		return model;
	}
	
	public void execute() {
		// TODO: add an actual computation here!  (I.e., the mandelbrot computation.)
		
		// The computation should produce a Model as a result
		
		// The computation can run for a long time if necessary:
		// because it runs in its own thread, it will not
		// block the GUI thread from processing events
		
		// Sleep to make the computation artifically 
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			throw new RuntimeException("This should not happen");
		}
		
		int[][] data = model.getData();
		
		// As an example computation, we just fill the selected region of the
		// model with some non-zero values.  THIS IS A MEANINGLESS COMPUTATION.
		float[] redMinMax = getRandPair();
		float[] greenMinMax = getRandPair();
		float[] blueMinMax = getRandPair();
		for (int i = region.getMinY(); i < region.getMinY() + region.getHeight(); i++) {
			for (int j = region.getMinX(); j < region.getMinX() + region.getWidth(); j++) {
				float vf = (((float)i - region.getMinY()) / region.getHeight());
				float hf = (((float)j - region.getMinX()) / region.getWidth());
				int r = (int)((redMinMax[0] + (redMinMax[1] - redMinMax[0]) * vf) * 255.0f);
				int g = (int)((greenMinMax[0] + (greenMinMax[1] - greenMinMax[0]) * hf) * 255.0f);
				int b = (int)((blueMinMax[0] + (blueMinMax[1] - blueMinMax[0]) * (1.0f-vf)) * 255.0f);
				int color = (r << 16) | (g << 8) | b;
				data[i][j] = color;
			}
		}
	}

	private float[] getRandPair() {
		float f1 = rand.nextFloat(), f2 = rand.nextFloat();
		return new float[]{Math.min(f1, f2), Math.max(f1, f2)};
	}
}
